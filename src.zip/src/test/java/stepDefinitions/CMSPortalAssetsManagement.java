package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import page.CMSPortalWebElementsPath;
import page.CMSPortalAssetsManagementsPath;
import setup.Setup;
import static org.junit.Assert.assertEquals;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import java.time.Duration;
import java.util.function.Function;

import org.openqa.selenium.WebDriver;
import setup.Setup;

public class
CMSPortalAssetsManagement{

    CMSPortalAssetsManagementsPath assets_Management_Variable = new CMSPortalAssetsManagementsPath();

    Setup setup = Setup.getInstance();
    WebDriver driver = setup.driver;


    //Gherkin steps for Verify Assets Management HP --------------------------------------------------------------------
    @Then("User clicks Content Management Module")
    public void click_Content_Management() throws InterruptedException{
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(20))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);

        WebElement content_Management_Dropdown = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(assets_Management_Variable.getContent_Management()));
            }
        });
        Thread.sleep(5000);
        content_Management_Dropdown.click();
        Thread.sleep(5000);

    }

    @Then("User clicks Assets Management section")
    public void click_Assets_Management() throws InterruptedException{
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(20))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);

        WebElement assets_Management_Section = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(assets_Management_Variable.getAssets_Management()));
            }
        });
        Thread.sleep(5000);
        assets_Management_Section.click();
        Thread.sleep(5000);
    }

    @Then("Verify the Assets Management page is displayed")
    public void verify_Main_Page_URL() {
        String expectedUrl = "https://cmsportal-dev.vsblty.net/home/asset-management";
        String actualUrl = driver.getCurrentUrl();
        Assert.assertEquals(expectedUrl, actualUrl);
    }

    @Then("Verify Asset Management options container in gray is displayed")
    public void verify_Options_Container(){
        WebElement gray_Options_Container = driver.findElement(By.xpath(assets_Management_Variable.getAssets_Option_Container()));
        Assert.assertTrue(gray_Options_Container.isDisplayed());
    }

    @Then("Verify Asset Management content is displayed")
    public void verify_Assets_Container(){
        WebElement assets_Container = driver.findElement(By.xpath(assets_Management_Variable.getAssets_Container()));
        Assert.assertTrue(assets_Container.isDisplayed());
    }

    //Gherkin steps for Assets Management Choose "VIDEO" HP ------------------------------------------------------------
    @Then("User clicks Asset Type dropdown")
    public void click_Asset_Type() throws InterruptedException{
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(20))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);

        WebElement assets_Management_Type = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(assets_Management_Variable.getAssets_Type_Dropdown()));
            }
        });
        Thread.sleep(5000);
        assets_Management_Type.click();
        Thread.sleep(5000);
    }

    @Then("User selects the option VIDEO from the dropdown list")
    public void click_Asset_Type_Option_Video() throws InterruptedException{
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(20))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);

        WebElement assets_Type_Video = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(assets_Management_Variable.getSelect_Asset_Video()));
            }
        });
        Thread.sleep(5000);
        assets_Type_Video.click();
        Thread.sleep(5000);
    }

    @Then("Verify all contents in the page are videos")
    public void verify_Assets_Videos(){
        WebElement videos_Container = driver.findElement(By.xpath(assets_Management_Variable.getVerify_Contents_For_Videos()));
        Assert.assertTrue(videos_Container.isDisplayed());
    }

    //Gherkin steps for Assets Management Choose "IMAGE" HP ------------------------------------------------------------
    @Then("User selects the option IMAGE from the dropdown list")
    public void click_Asset_Type_Option_Image() throws InterruptedException{
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(20))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);

        WebElement assets_Type_Image = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(assets_Management_Variable.getSelect_Asset_Image()));
            }
        });
        Thread.sleep(5000);
        assets_Type_Image.click();
        Thread.sleep(5000);
    }

    @Then("Verify all contents in the page are images")
    public void verify_Assets_Images(){
        WebElement images_Container = driver.findElement(By.xpath(assets_Management_Variable.getVerify_Contents_For_Images()));
        Assert.assertTrue(images_Container.isDisplayed());
    }

    //Gherkin steps for Assets Management Choose "HTML" HP ------------------------------------------------------------
    @Then("User selects the option HTML from the dropdown list")
    public void click_Asset_Type_Option_Html() throws InterruptedException{
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(20))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);

        WebElement assets_Type_Html = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(assets_Management_Variable.getSelect_Asset_Html()));
            }
        });
        Thread.sleep(5000);
        assets_Type_Html.click();
        Thread.sleep(5000);
    }

    @Then("Verify all contents in the page are html")
    public void verify_Assets_Html(){
        WebElement html_Container = driver.findElement(By.xpath(assets_Management_Variable.getVerify_Contents_For_Html()));
        Assert.assertTrue(html_Container.isDisplayed());
    }

    //Gherkin steps for Assets Management Choose "VAST" HP ------------------------------------------------------------
    @Then("User selects the option VAST from the dropdown list")
    public void click_Asset_Type_Option_Vast() throws InterruptedException{
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(20))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);

        WebElement assets_Type_Vast = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(assets_Management_Variable.getSelect_Asset_Vast()));
            }
        });
        Thread.sleep(5000);
        assets_Type_Vast.click();
        Thread.sleep(5000);
    }

    //Gherkin steps for Assets Management Choose "PERPETUAL" HP ------------------------------------------------------------
    @Then("User selects the option PERPETUAL from the dropdown list")
    public void click_Asset_Type_Option_Perpetual() throws InterruptedException{
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(20))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);

        WebElement assets_Type_Perpetual = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(assets_Management_Variable.getSelect_Asset_Perpetual()));
            }
        });
        Thread.sleep(5000);
        assets_Type_Perpetual.click();
        Thread.sleep(5000);
    }

    @Then("Verify all contents in the page are perpetual")
    public void verify_Assets_Perpetual(){
        WebElement perpetual_Container = driver.findElement(By.xpath(assets_Management_Variable.getVerify_Contents_For_Perpetual()));
        Assert.assertTrue(perpetual_Container.isDisplayed());
    }

    //Gherkin steps for Assets Management "Fuzzy" - HP -----------------------------------------------------------------
    @Then("Verify Fuzzy checkbox is selected")
    public void verify_Fuzzy_Checkbox(){
        WebElement fuzzy_Checkbox = driver.findElement(By.xpath(assets_Management_Variable.getVerify_Checkbox_Fuzzy()));
        assertEquals(true, fuzzy_Checkbox.isSelected());
    }

    @Then("Enter the name of an asset in the Search Name field")
    public void user_Searches_For_An_Asset() throws InterruptedException{
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(10))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);

        WebElement search_Asset = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(assets_Management_Variable.getAssets_Management_Search_Input()));
            }
        });
        Thread.sleep(2000);
        search_Asset.clear();
        Thread.sleep(2000);
        search_Asset.sendKeys(assets_Management_Variable.getAsset_Name_For_Fuzzy());
    }

    @Then("Verify the searched assets are displayed on the screen")
    public void verify_Asset_Is_Displayed() {
        WebElement specific_Asset = driver.findElement(By.xpath(assets_Management_Variable.getVerify_Asset_Title()));
        Assert.assertTrue(specific_Asset.isDisplayed());
    }

    @Then("Verify all contents in the page are vast")
    public void verify_Assets_Vast(){
        WebElement vast_Container = driver.findElement(By.xpath(assets_Management_Variable.getVerify_Contents_For_Vast()));
        Assert.assertTrue(vast_Container.isDisplayed());
    }
















}
