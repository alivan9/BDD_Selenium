package stepDefinitions;
import java.util.List;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import page.CMSPortalWebElementsPath;
import page.LandingPage;
import setup.Setup;

import java.time.Duration;
import java.util.function.Function;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


public class CMSPortalPlaylistManagement  {

    CMSPortalWebElementsPath cmsPortal = new CMSPortalWebElementsPath();

    Setup setup = Setup.getInstance();
    WebDriver driver = setup.driver;


@Then("user click tab Content Management")
    public void user_click_tab_Content_Management() throws InterruptedException {
    Thread.sleep(5000);
    System.out.println("driver playlist:"+driver);
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);

    WebElement contentManagementTab = fwait.until(new Function<WebDriver, WebElement>() {
        @Override
        public WebElement apply(WebDriver webDriver) {
            return webDriver.findElement(By.xpath(cmsPortal.getContentManagementTab()));
        }
    });



    //System.out.println(contentManagementTab);
    contentManagementTab.click();
    Thread.sleep(3000);
    }

    @Then("user click tab Playlists Management")
    public void userClickTabPlaylistsManagement() throws InterruptedException {

        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);

        WebElement contentPlaylistTab = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getPlaylistsManagementTab()));
            }
        });
        System.out.println("contentPlaylistTab"+contentPlaylistTab);
        contentPlaylistTab.click();
        Thread.sleep(3000);
    }

    @Then("user click for create new playlists")
    public void userClickForCreateNewPlaylists() throws InterruptedException {

        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);

        WebElement contentNewPlaylistButton = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getNewPlaylistButton()));
            }
        });
      //  System.out.println("contentPlaylistTab"+contentPlaylistTab);
        contentNewPlaylistButton.click();
        Thread.sleep(3000);
    }

    @Then("user click button clear filter")
    public void userClickButtonClearFilter() throws InterruptedException {

        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);

        WebElement contentClearFilterButton = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getClearFilterButton()));
            }

        });

        contentClearFilterButton.click();
    }
    @Then("user verify clear filter")
    public void userVerifyClearFilter() throws InterruptedException {
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        WebElement contentClearFilterMessage = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getMsgClearFilterDropdown()));
            }
        });
      assertEquals(contentClearFilterMessage.getText(),"Choose...");
    }

    //  Scenario:Display of the different options in Playlists Management

    @Then("user can see all te option in this section")
    public void userCanSeeAllTeOptionInThisSection() throws InterruptedException {
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        WebElement contentNewButton = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getNewButtonPlaylist()));
            }
        });
        WebElement contentDeletePlaylist = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getDeleteButtonPlaylist()));
            }
        });
        WebElement contentEditPlaylist = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getEditButtonPlaylist()));
            }
        });
        WebElement contentClonePlaylist = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getCloneButtonPlaylist()));
            }
        });
        contentDeletePlaylist.isDisplayed();
        contentEditPlaylist.isDisplayed();
        contentClonePlaylist.isDisplayed();
        contentClonePlaylist.isDisplayed();
    }

//Create new playlist - HP
    @Then("user fill name for playlist")
    public void userFillNameForPlaylist() throws InterruptedException {
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        WebElement contentNamePlaylist = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getInputNamePlaylist()));
            }
        });
        contentNamePlaylist.click();
        contentNamePlaylist.sendKeys("Nombre1");
    }

    @Then("user add assets for playlist")
    public void userAddAssetsForPlaylist() throws InterruptedException {
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        WebElement contentSelectAssetPlaylist = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getAddAssetFirst()));
            }
        });
        WebElement contentSelectAssetPlaylistSecond = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getAddAssetFirst()));
            }
        });
        contentSelectAssetPlaylist.click();
        contentSelectAssetPlaylistSecond.click();
        Thread.sleep(5000);

    }
    @Then("user save new playlist")
    public void useSaveNewPlaylist() throws InterruptedException {
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        WebElement contentButtonSave = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getSaveButton()));
            }
        });
        contentButtonSave.click();
        Thread.sleep(2000);
    }
    @Then("user will see the message \"Name is required\"")
    public void userWillSeeTheMessageNameIsRequired() throws InterruptedException {
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        WebElement contentMsgUserIsRequired = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getMsgUserIsRequired()));
            }
        });
        assertEquals(contentMsgUserIsRequired.getText(),"Name is required.");

    }

    @Then("user will see a button disabled")
    public void userWillSeeButtonDisabled() throws InterruptedException {
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        WebElement contentBtnSaveDisable = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getSaveButtonDisabledPlaylist()));
            }
        });

        contentBtnSaveDisable.isDisplayed();
    }
    @Then("user click close page playlist")
    public void userClickClosePagePlaylist() throws InterruptedException {
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        WebElement contentBtnClosePage = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getCloseButtonPlaylist()));
            }
        });

        contentBtnClosePage.click();
        Thread.sleep(3000);
    }

    //spanMessageSelectAsset
    @Then("user verify notification of mandatory assets")
    public void userVerifyNotificationMandatoryAssets() throws InterruptedException {
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        WebElement contentMsgSelectAsset= fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getSpanMessageSelectAsset()));
            }
        });

        contentMsgSelectAsset.isDisplayed();
        assertEquals(contentMsgSelectAsset.getText(),"You need to select at least two assets to create/modify the playlist");
        Thread.sleep(5000);
    }
    @Then("user add one assets for playlist")
    public void userAddOneAssetsForPlaylist() throws InterruptedException {
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(8))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        WebElement contentSelectAssetPlaylist = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getAddAssetFirst()));
            }
        });
        contentSelectAssetPlaylist.click();
        Thread.sleep(5000);

    }
}






