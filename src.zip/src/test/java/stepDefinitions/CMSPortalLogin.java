package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import page.CMSPortalWebElementsPath;
import page.LandingPage;
import setup.Setup;

import java.time.Duration;
import java.util.function.Function;

public class CMSPortalLogin {
    CMSPortalWebElementsPath cmsPortal = new CMSPortalWebElementsPath();
    Setup setup = Setup.getInstance();
    WebDriver driver = setup.driver;
    @Given("user can visit portal")
    public void user_can_visit_portal() throws InterruptedException {
        driver.get(cmsPortal.getBaseURL());
        Thread.sleep(9000);
    }
    @When("user enter user name")
    public void user_put_valid_input() throws InterruptedException{
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(10))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);
        WebElement userName = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.id(cmsPortal.getUserNameIDPath()));
            }
        });
        Thread.sleep(1000);
        userName.clear();
        Thread.sleep(1000);
        userName.sendKeys(cmsPortal.getTenantUser());
        //  WebElement userName = common.initializeWebElementWithFluentWait(common.getWebDriver(),cmsPortal.getUserNameIDPath());

    }
    @Then("user enter password")
    public void userCanVerifyInput() throws InterruptedException{
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(10))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);

        WebElement password = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.id(cmsPortal.getPasswordIDPath()));
            }
        });
        Thread.sleep(1000);
        password.clear();
        Thread.sleep(1000);
        password.sendKeys(cmsPortal.getTenantPassword());
    }

    @Then("user click button login")
    public void userclickbutton() throws InterruptedException{
        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(15))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);

        WebElement loginButton = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getLoginButtonXPath()));
            }
        });
        Thread.sleep(4000);
        loginButton.click();
        Thread.sleep(4000);
    }

    @Then("user click close Browser")
    public void userclickcloseBrowser() throws InterruptedException {

        Wait<WebDriver> fwait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(10))
                .pollingEvery(Duration.ofMillis(200))
                .ignoring(NoSuchElementException.class);

        WebElement userOptionsButton = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getUserOptionsXPath()));
            }
        });

        userOptionsButton.click();

        WebElement logoutButton = fwait.until(new Function<WebDriver, WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.xpath(cmsPortal.getLogoutButtonXPath()));
            }
        });

        logoutButton.click();
        Thread.sleep(3000);


    }

}
