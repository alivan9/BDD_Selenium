package page;

import lombok.Data;
@Data
public class CMSPortalAssetsManagementsPath extends Common{
    private String content_Management = "/html/body/app-root/app-home/div/app-sidebar/div/div[2]/ul/li[2]";
    private String assets_Management = "/html/body/app-root/app-home/div/app-sidebar/div/div[2]/ul/li[2]/ul/li[1]/a/span";
    private String assets_Management_URL = "https://cmsportal-dev.vsblty.net/home/asset-management";
    private String assets_Option_Container = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[2]";
    private String assets_Container = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[4]/div";

    private String assets_Type_Dropdown = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[2]/div/div/div[1]/select";
    private String select_Asset_Video = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[2]/div/div/div[1]/select/option[2]";
    private String verify_Contents_For_Videos = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[4]/div/div/div[2]";

    private String select_Asset_Image = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[2]/div/div/div[1]/select/option[3]";
    private String verify_Contents_For_Images = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[4]/div/div/div[2]";

    private String select_Asset_Html = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[2]/div/div/div[1]/select/option[4]";
    private String verify_Contents_For_Html = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[4]/div/div/div[2]";

    private String select_Asset_Vast = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[2]/div/div/div[1]/select/option[5]";
    private String verify_Contents_For_Vast = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[4]/div/div/div[2]/div[2]";

    private String select_Asset_Perpetual = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[2]/div/div/div[1]/select/option[6]";
    private String verify_Contents_For_Perpetual = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[4]/div/div/div[2]/div[2]";

    private String verify_Checkbox_Fuzzy = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[2]/div/div/div[3]/div[2]/input";
    private String assets_Management_Search_Input = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[2]/div/div/div[2]/div/vn-search/input";
    private String asset_Name_For_Fuzzy = "barcel";
    private String verify_Asset_Title = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[4]/div/div/div[2]";

    private String asset_Checkbox_Exact = "";
    private String asset_Name_For_Exact = "barcel-logo";
    private String verify_Asset_Specific_Title = "/html/body/app-root/app-home/div/div/div/div/app-asset-management/div[4]/div/div/div[2]/div[2]/div/div/div[3]/div/div/div/h6";


}
