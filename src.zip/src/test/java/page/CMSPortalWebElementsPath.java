package page;

import lombok.Data;

@Data
public class CMSPortalWebElementsPath extends Common {

    private final String baseURL = "https://www.facebook.com/";
    private String tenantUser = "fpuebla@vsblty.net";
    private String tenantPassword = "Improving1";
    private String systemAdmin = "admin@vsblty.net";
    private String systemPassword = "AI1scool!@5";
    private String userNameIDPath = "inputLastEnterUsername";
    private String passwordIDPath = "inputLastEnterPassword";
    private String loginButtonXPath = "//*[@class='d-grid']";
    private String userOptionsXPath = "//*[@class='user-box dropdown']";
    private String logoutButtonXPath = "//*[contains(text(),'Logout')]";
    private String administrationTabXPath = "//span[contains(text(),'Administration')]";
    private String newTenantAdminButton = "//button[contains(text(),'New Tenant Admin')]";
    private String newSysAdmin = "//button[contains(text(),'New SysAdmin')]";
    private String tenantNameTextBox = "//input[@placeholder='Tenant name']";

    private String userManagementTab = "//span[contains(text(),'User Management')]";
    private String emailAddressBox = "//*[@placeholder='email']";
    private String firstNameBox = "//*[@placeholder='First Name']";
    private String lastNameBox = "//*[@placeholder='Last Name']";
    private String detailsBox = "//*[@placeholder='Details']";
    private String activationMethodDropdown = "//*[@class='form-select ng-untouched ng-pristine ng-valid']";
    private String closeButton = "(//button[@data-bs-dismiss='modal'])[2]";
    private String saveButton = "//*[contains(text(),'Save')]";

    private String customersManagementTab = "//span[contains(text(),'Customers Management')]";
    private String titleSearchBox = "//input[@class='form-control border-start-0']";// GENERAL
    private String countryBox = "//input[@placeholder='Country']";

    private String cityBox = "//input[@placeholder='City']";
    private String stateProvinceBox = "//*[@placeholder='State / Province']";
    private String zipPostalCodeBox = "//*[@placeholder='Zip / Postal Code']";
    private String addressBox = "//*[@placeholder='Address']";
    private String address2Box = "//*[@placeholder='Address 2']";
    private String phoneBox = "//*[@placeholder='Phone']";
    private String emailBox = "//*[@placeholder='email']";
    private String additionalInfoDropdown = "//select[@class='form-select mb-3 ng-untouched ng-pristine ng-valid']";
    private String keyBox = "//input[@placeholder='Key']";
    private String valueBox = "//input[@placeholder='Value']";
    private String booleanValue = "(//input[@type='checkbox'])[4]";
    private String addKeyButton = "//button[@class='btn btn-outline-primary ng-star-inserted']";
    private String trashButton = "//button[@class='btn btn-outline-danger']";

    private String deviceManagementTab = "//a[@ng-reflect-router-link='/home/device-management']";
    private String nameBox = "(//*[@placeholder='Name'])[3]";
    private String labelBox = "//*[@placeholder='Label']";
    private String typeBox = "//input[@placeholder='Type']";
    private String customerBox = "//input[@placeholder='Customer']";

    private String deviceStatusTab = "//*[contains(text(),'Device Status')]";

    private String contentManagementTab = "//*[contains(text(),'Content Management')]";

    private String assetsManagementTab = "//span[contains(text(),'Assets Management')]";
    private String assetType = "//*[@class='form-select']";
    private String assetVideo = "//*[@ng-reflect-ng-value='VIDEO']";
    private String assetImage = "//*[@ng-reflect-ng-value='IMAGE']";
    private String assetURL = "//option[@ng-reflect-ng-value='URL']";
    private String assetVast = "//option[@ng-reflect-ng-value='VAST']";
    private String assetPerpetual = "//*[@ng-reflect-ng-value='HTML']";
    private String assetSearchBox = "//*[@class='input-group-text bg-primary']";
    private String exactOption = "//*[@class='form-check-label' and contains(text(),'Exact')]";
    private String fuzzyOption = "//*[@class='form-check-label' and contains(text(),'Fuzzy')]";
    private String listViewButton = "//*[@class='btn btn-outline-white']";
    private String gridViewButton = "//*[@class='btn btn-primary' and contains(text(),' Grid ')]";
    private String deleteAssetButton = "//*[@class='btn btn-danger me-1']";
    private String displayAssetInUse = "//*[@type='checkbox']";

    private String playlistsManagementTab = "//span[contains(text(),'Playlists Management')]";
    private String editPlaylistsButton = "//*[contains(text(),' Edit playlist ')]";
    private String searchPlaylistBox = "//*[@placeholder='Playlist Name']";
    private String searchAsset = "//input[@placeholder='Asset Name']";

    private String enrollmentManagementTab = "//*[contains(text(),'Enrollment Management')]";
    private String groupManagementTab = "//span[contains(text(),'Groups management')]";
    private String groupNameBox = "//*[@placeholder='Name']";

    private String peopleEnrollmentTab = "//span[contains(text(),'People enrollment')]";
    //private String firstNameBox = "//*[@placeholder='First name']"; //REPEATED
    //private String lastNameBox = "//*[@placeholder='Last Name']"; //REPEATED
    private String uploadFileButton = "//*[@class='file-drop-zone-overlay row g-1 ps-1 disabled']";

    private String deviceEnrollmentTab = "//span[contains(text(),'Device enrollment')]";

    private String campaignsTab = "//*[contains(text(),'Campaigns')]"; //
    private String displaysLayoutTab = "//span[contains(text(),'Displays layout')]";
    private String displaySelectDropdownList = "//select[@class='form-select ng-pristine ng-valid ng-touched']";
    private String landscapeOption = "//option[@value='LANDSCAPE']";
    private String portraitOption = "//option[@value='PORTRAIT']";
    private String widthSizeBox = "//input[@placeholder='Width']";
    private String heightSizeBox = "//input[@placeholder='Height']";
    private String stretchScreenCheckbox = "//input[@class='form-check-input ng-untouched ng-pristine ng-valid']";

    private String designerTab = "//span[contains(text(),'Designer')]";
    private String layoutName = "//input[@placeholder='Layout Name']";
    private String dimensionsBox = "//select[@ng-reflect-is-disabled='false']";
    private String autoResizeCheckbox = "//input[@id='designercomponent_designCanvasSizesBounds.zone.autoResize_166680857402603000']";
    private String previewButton = "//button[@class='btn btn-warning me-1']";
    private String saveDraftButton = "//button[@tooltip=’Save a local draft<br>ctrl + shift + s']";
    private String deleteDraftButton = "//button[@tooltip='Delete current draft<br>ctrl + shift + delete']";
    private String informationButton = "//*[@class='fadeIn animated bx bx-info-square']";
    private String manualEditOptions = "//*[@class='fadeIn animated bx bx-box']";
    private String assetsButton = "//*[@class='btn btn-outline-secondary']";
    private String playlistButton = "//button[text()=' Playlists ']";
    private String searchBox = "//input[@placeholder='Search by name or tag']";
    private String clearFiltersButton = "//button[text()='Clear filters']";
    private String typeChooseAssetOption = "//select[contains(@class,'form-select ng-pristine')]";

    private String campaignTab = "//a[@ng-reflect-router-link='/home/campaign']";//"//a[@href='/home/campaign']";
    private String previousButton = "//a[contains(text(),'Previous')]";
    private String todayButton = "//a[contains(text(),'Today')]";
    private String nextButton = "//a[contains(text(),'Next')]";
    private String addCampaignButton = "//*[contains(text(),' Add Campaign ')]";
    private String monthButton = "//a[contains(text(),'Month')]";
    private String weekButton = "//a[contains(text(),'Week')]";
    private String dayButton = "//a[contains(text(),'Day')]";
    private String calendarDayButtonTemplate = "//div[@aria-label='Monday September 26']";
    private String campaignNameTextBox = "//input[@ng-reflect-name='Name']";
    private String startsAtBox = "//input[@name='starDate']";
    private String endsAtBox = "//input[@name='endDate']";
    private String layoutDropdownList = "//select[@name='LayoutId']";
    private String optionsTemplate = "//option[text()='LAYOUT 1 ']";

    private String campaignDevice = "//span[contains(text(),'Campaign Device')]";
    private String campaignTemplate = "(//td[text()='TEST-CAMPAIGN'])[2]";
    private String addAllInPageButton = "//button[contains(text(),'Add all in page')]";
    private String removeAllDevices = "//button[contains(text(),'Remove all devices')]";

    private String dashboardTab = "//*[@class='menu-title' and contains(text(),'Dashboard')]";
    private String tenantAdminOption = "//*[@class='user-box dropdown' ]";
    private String profileOption = "//*[text()='Profile']";
    private String searchButton = "//*[@id='search']";
    private String searchBoxDashboard = "//*[@class='form-control border-start-0']";

    private String newButton = "//*[@class='btn btn-success mr-1 btn-border-white']";
    private String deleteButton = "//*[@class='btn btn-danger mr-1 btn-border-white']";
    private String upperSearchBox = "//*[@class='form-control search-control']";
    private String upperSearchButton = "//*[@class='position-absolute top-50 search-show translate-middle-y']";

    //PROFILE
    private String goHomeButton = "//*[contains(text(),'Go Home')]";
    private String backButton = "//*[contains(text(),'Back')]";
    private String itemsPerPage = "//*[@class='form-control ng-untouched ng-pristine ng-valid']";

    //PLAYLIST MANAGEMENT
    private String newPlaylistButton = "//button[contains(text(),'New')]";
    private String clearFilterButton = "(//button[contains(text(),'Clear filters')])[1]";
    private String msgClearFilterDropdown = ("//*[@id='editModal']/div/div/div[2]/vn-assets-list/div/div[1]/div[2]/div[1]/div/div[2]/div/select/option[1]");

    //PLAYLIST DISPLAY OPTIONS
    private String newButtonPlaylist = "//button[contains(text(),'New')]";
    private String deleteButtonPlaylist = "//button[contains(text(),'Delete playlist')]";
    private String editButtonPlaylist = "//button[contains(text(),'Edit playlist')]";
    private String cloneButtonPlaylist = "//button[contains(text(),'Clone playlist')]";

    // CREATE A NEW PLAYLIST
    private String inputNamePlaylist = "(//input[@placeholder='Name'])[1]";
    private String addAssetFirst = "(//div[contains(@class,'vsblty-assets-list')]//div[contains(@class,'row')]//*[1])[2]";
    private String addAssetSecond = "(//div[contains(@class,'vsblty-assets-list')]//div[contains(@class,'row')]//*[1])[3]";
    private String saveButtonPlaylist = "(//button[contains(text(),'Save')])[1]";
    private String msgUserIsRequired = "(//div[contains(@class,'invalid-feedback')])[1]";
    private String saveButtonDisabledPlaylist = "//button[contains(text(),'Save')][@disabled]";
    private String closeButtonPlaylist = "//button[contains(@class,'btn-close')][1]";
    private String spanMessageSelectAsset = "/html/body/app-root/vn-toasts/ngb-toast/div/span";
}
