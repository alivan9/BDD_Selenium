# CMSPortal

# Technology and Tools used:
 -  Selenium
- Cucumber
- Java
- Junit
- Maven
- Intellij IDEA

# Prerequisite:
- Java 8 or latest version
- SDK java 17.0 or higher 
- Intellij IDEA or any java IDE
- Configure JAVA_HOME and MAVEN_HOME

# How to run this project:
- Clone this project
- Right click on the .feature and run the test
